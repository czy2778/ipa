# 未签名 IPA 构建步骤（3 分钟拿到）

## 为什么需要这一步
编译 iOS 必须用苹果的 Xcode/macOS 环境。下面用 **GitHub Actions 的免费 macOS 云主机**自动编译，
你不用装任何东西，点几下按钮就能下载未签名 ipa。

## 步骤

### 1. 把本目录（gaychou_ipa 整个文件夹）传到你的 GitHub 仓库
最简单：GitHub 网页 → 新建仓库（私有即可）→「uploading an existing file」
把 `GayChouApp/` 和 `.github/` 两个目录整个拖进去 → Commit。

> 注意：`.github/` 是隐藏文件夹，拖拽上传时要确保它也在里面（文件夹里能看到 `.github/workflows/build-ipa.yml`）。

### 2. 触发构建
仓库页面 → 顶部 **Actions** 标签 →（首次会提示启用 workflow，点 Enable）→
左侧选 **Build Unsigned IPA** → 右边 **Run workflow** → **Run workflow** 确认。

### 3. 下载未签名 ipa
等 3~5 分钟，构建完成后进入该次运行页面，底部 **Artifacts** 区会显示
**GayChou-unsigned-ipa**，点它下载，解压就是 `GayChou-unsigned.ipa`。

## 4. 拿到 ipa 之后自己签名
- **轻松签 / 全能签**（iOS 上直接操作）：导入 ipa → 导入你的 p12 证书 + mobileprovision → 签名安装
- **电脑端**：`codesign` + `ldid`，或用爱思助手/AltStore 侧载
- Bundle ID 默认 `top.gaychou.app`，如证书不匹配，签名的工具里改成你描述文件里的 ID（重签时修改 bundle id 即可，不用回来改源码）

## 常见问题
| 问题 | 处理 |
|---|---|
| Actions 标签看不到 | 仓库 Settings → Actions → General → Allow all actions |
| 构建失败看日志 | 点失败的 job 看红色步骤，把报错发我 |
| 私有仓库配额 | 私有仓库每月有 2000 分钟免费 macOS 额度，本流程一次约 5 分钟，完全够用 |
| 想改版本号/名字 | 本地改 `project.pbxproj` 里的 `MARKETING_VERSION` / `CFBundleDisplayName` 后重新上传 |
